import { motion } from "framer-motion";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useState, useMemo } from "react";
import { orderHistoryData } from "../customer/CustomerOrdersData";

// Helper function to calculate sales data based on time range
const calculateSalesData = (orderHistoryData, selectedTimeRange) => {
  const currentDate = new Date();
  const startDate = new Date(currentDate);
  let endDate = new Date(currentDate);

  switch (selectedTimeRange) {
    case "This Week":
      startDate.setDate(currentDate.getDate() - currentDate.getDay()); // Start of this week (Sunday)
      break;

    case "This Month":
      startDate.setDate(1); // Start of the current month
      break;

    case "This Quarter":
      const currentQuarter = Math.floor(currentDate.getMonth() / 3) * 3;
      startDate.setMonth(currentQuarter); // Start of the current quarter
      startDate.setDate(1);
      break;

    case "This Year":
      startDate.setMonth(0); // Start of the current year
      startDate.setDate(1);
      break;

    default:
      startDate.setDate(currentDate.getDate() - currentDate.getDay()); // Default to this week
  }

  // Flatten and filter orders based on the selected time range
  const filteredOrders = orderHistoryData
    .flatMap((customer) => customer.orders)
    .filter((order) => new Date(order.orderDate) >= startDate && new Date(order.orderDate) <= endDate);

  // Aggregate sales data by month (or any other unit)
  const salesByMonth = {};
  filteredOrders.forEach((order) => {
    const orderDate = new Date(order.orderDate);
    const month = orderDate.toLocaleString("default", { month: "short" });

    if (!salesByMonth[month]) {
      salesByMonth[month] = 0;
    }

    salesByMonth[month] += order.totalAmount;
  });

  // Prepare data for the chart
  return Object.keys(salesByMonth).map((month) => ({
    month,
    sales: salesByMonth[month],
  }));
};

const SalesOverviewChart = () => {
  const [selectedTimeRange, setSelectedTimeRange] = useState("This Month");

  const salesData = useMemo(() => {
    return calculateSalesData(orderHistoryData, selectedTimeRange);
  }, [selectedTimeRange]);

  return (
    <motion.div
      className="bg-gray-800 bg-opacity-50 backdrop-blur-md shadow-lg rounded-xl p-6 border border-gray-700 mb-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
    >
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-gray-100">Sales Overview</h2>

        <select
          className="bg-gray-700 text-white rounded-md px-3 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={selectedTimeRange}
          onChange={(e) => setSelectedTimeRange(e.target.value)}
        >
          <option>This Week</option>
          <option>This Month</option>
          <option>This Quarter</option>
          <option>This Year</option>
        </select>
      </div>

      <div className="w-full h-80">
        <ResponsiveContainer>
          <AreaChart data={salesData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="month" stroke="#9CA3AF" />
            <YAxis stroke="#9CA3AF" />
            <Tooltip
              contentStyle={{ backgroundColor: "rgba(31, 41, 55, 0.8)", borderColor: "#4B5563" }}
              itemStyle={{ color: "#E5E7EB" }}
            />
            <Area type="monotone" dataKey="sales" stroke="#8B5CF6" fill="#8B5CF6" fillOpacity={0.3} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
};

export default SalesOverviewChart;
