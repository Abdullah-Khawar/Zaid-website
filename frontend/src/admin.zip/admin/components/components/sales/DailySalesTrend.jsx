import { motion } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useMemo } from "react";

// Helper function to calculate daily sales from orderHistoryData
const getDailySalesData = (orderHistoryData) => {
  const salesByDate = {};

  // Iterate through each customer's orders
  orderHistoryData.forEach((customer) => {
    customer.orders.forEach((order) => {
      if (order.orderStatus === "delivered") {
        const date = new Date(order.orderDate);
        const day = date.toLocaleDateString(); // Format to "MM/DD/YYYY"

        if (!salesByDate[day]) {
          salesByDate[day] = 0;
        }

        // Add the totalAmount to the corresponding day
        salesByDate[day] += order.totalAmount;
      }
    });
  });

  // Convert the sales data to an array sorted by date
  return Object.keys(salesByDate).map((date) => ({
    name: date,
    sales: salesByDate[date],
  }));
};

const DailySalesTrend = ({ orderHistoryData }) => {
  // Use memoization to avoid recalculating daily sales on every render
  const dailySalesData = useMemo(() => getDailySalesData(orderHistoryData), [orderHistoryData]);

  return (
    <motion.div
      className='bg-gray-800 bg-opacity-50 backdrop-blur-md shadow-lg rounded-xl p-6 border border-gray-700'
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
    >
      <h2 className='text-xl font-semibold text-gray-100 mb-4'>Daily Sales Trend</h2>

      <div style={{ width: "100%", height: 300 }}>
        <ResponsiveContainer>
          <BarChart data={dailySalesData}>
            <CartesianGrid strokeDasharray='3 3' stroke='#374151' />
            <XAxis dataKey='name' stroke='#9CA3AF' />
            <YAxis stroke='#9CA3AF' />
            <Tooltip
              contentStyle={{
                backgroundColor: "rgba(31, 41, 55, 0.8)",
                borderColor: "#4B5563",
              }}
              itemStyle={{ color: "#E5E7EB" }}
            />
            <Bar dataKey='sales' fill='#10B981' />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
};

export default DailySalesTrend;
