import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Search, Eye } from "lucide-react";
import { orderHistoryData } from "../customer/CustomerOrdersData";
import { Dialog, DialogActions, DialogContent, DialogTitle, Typography, Button } from "@mui/material"; // Import Material UI components for modal

const OrdersTable = () => {
  // Initialize state for search term, filtered orders, selected order, and modal visibility
  const [searchTerm, setSearchTerm] = useState("");
  const [allOrders, setAllOrders] = useState([]); // Store all orders
  const [filteredOrders, setFilteredOrders] = useState([]); // Store filtered orders
  const [selectedOrder, setSelectedOrder] = useState(null); // To store the selected order details
  const [openModal, setOpenModal] = useState(false); // To manage modal visibility

  // Flatten orderHistoryData on mount
  useEffect(() => {
    // Flatten all the orders from all customers into a single array
    const allOrdersData = orderHistoryData.flatMap(customer => 
      customer.orders.map(order => ({
        ...order,
        customerName: customer.customerName, // Add customer name to each order for display
        customerEmail: customer.customerEmail, // Optional, add other customer details if needed
        customerAddress: customer.customerAddress,
      }))
    );
    setAllOrders(allOrdersData); // Store all orders
    setFilteredOrders(allOrdersData); // Set initial filtered orders to be all orders
  }, []);

  // Handle search input change
  const handleSearch = (e) => {
    const term = e.target.value.toLowerCase();
    setSearchTerm(term);

    // Filter orders based on search term (search orderId or customerName)
    const filtered = allOrders.filter(
      (order) =>
        order.orderId.toLowerCase().includes(term) ||
        order.customerName.toLowerCase().includes(term)
    );
    setFilteredOrders(filtered);
  };

  // Open modal and set selected order
  const handleOpenModal = (order) => {
    setSelectedOrder(order);
    setOpenModal(true);
  };

  // Close modal
  const handleCloseModal = () => {
    setOpenModal(false);
  };

  return (
    <motion.div
      className="bg-gray-800 bg-opacity-50 backdrop-blur-md shadow-lg rounded-xl p-6 border border-gray-700"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
    >
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-100">Order List</h2>
        <div className="relative">
          <input
            type="text"
            placeholder="Search orders..."
            className="bg-gray-700 text-white placeholder-gray-400 rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={searchTerm}
            onChange={handleSearch}
          />
          <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-700">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Order ID
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Customer
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Total
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>

          <tbody className="divide divide-gray-700">
            {/* Map through filtered orders */}
            {filteredOrders.map((order) => (
              <motion.tr
                key={order.orderId}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-100">
                  {order.orderId}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-100">
                  {order.customerName}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-100">
                  ${order.totalAmount.toFixed(2)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                  <span
                    className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      order.orderStatus === "delivered"
                        ? "bg-green-100 text-green-800"
                        : order.orderStatus === "shipped"
                        ? "bg-blue-100 text-blue-800"
                        : order.orderStatus === "pending"
                        ? "bg-yellow-100 text-yellow-800"
                        : "bg-red-100 text-red-800"
                    }`}
                  >
                    {order.orderStatus}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{order.orderDate}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                  <button
                    className="text-indigo-400 hover:text-indigo-300 mr-2"
                    onClick={() => handleOpenModal(order)} // Open modal on click
                  >
                    <Eye size={18} />
                  </button>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal to view order details */}
      <Dialog open={openModal} onClose={handleCloseModal}>
        <motion.div
          className="mx-auto w-full flex-none lg:max-w-2xl xl:max-w-4xl flex flex-col gap-4 p-6 bg-white rounded-lg shadow-lg border border-gray-200"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <DialogTitle className="text-2xl font-semibold text-gray-800 mb-4">
            Order Details
          </DialogTitle>
          <DialogContent className="bg-white p-6">
            {selectedOrder && selectedOrder.products && selectedOrder.products.length > 0 ? (
              selectedOrder.products.map((product, index) => (
                <div
                  key={index}
                  className="space-y-4 rounded-lg border border-gray-200 bg-white p-4 shadow-sm hover:shadow-lg dark:border-gray-700 dark:bg-gray-800 md:p-6"
                >
                  <div className="flex items-center justify-between space-x-6">
                    <div className="shrink-0">
                      <img
                        className="h-20 w-20 rounded-md object-cover hidden md:block"
                        src={product.colors.find(
                          (color) => color.name === product.selectedColor
                        )?.imageSrc}
                        alt={product.productName}
                      />
                    </div>
                    <div className="flex-1 space-y-2">
                      <Typography
                        variant="body1"
                        className="text-base font-medium text-gray-800 dark:text-white"
                      >
                        {product.productName}
                      </Typography>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        <p>Color: {product.selectedColor}</p>
                        {product.selectedSize && <p>Size: {product.selectedSize}</p>}
                      </div>
                    </div>
                    <div className="flex items-center justify-end space-x-4">
                      <p className="text-sm font-semibold text-gray-800 dark:text-white">
                        Qty: {product.quantity}
                      </p>
                      <p className="text-sm font-semibold text-gray-800 dark:text-white">
                        Price: ${product.discountedPrice.toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <Typography variant="body1" color="textSecondary">
                No products available for this order.
              </Typography>
            )}
          </DialogContent>

          {/* CLOSE BUTTON */}
          <DialogActions className="flex justify-end mt-6 bg-gray-100">
            <Button
              onClick={handleCloseModal}
              color="secondary"
              variant="contained"
              className="w-full sm:w-auto bg-gray-600 text-white px-6 py-2 rounded-md hover:bg-green-500 focus:outline-none focus:ring-2 focus:ring-gray-700"
            >
              Close
            </Button>
          </DialogActions>
        </motion.div>
      </Dialog>
    </motion.div>
  );
};

export default OrdersTable;
