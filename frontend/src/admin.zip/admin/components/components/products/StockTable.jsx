import { motion } from "framer-motion";
import { useMemo, useState, useEffect } from "react";
import { orderHistoryData } from "../customer/CustomerOrdersData";
import getSalesByYearAndMonth from "../sales/GetSalesByYearAndMonth";
import { initialProducts } from "../../../../customer/components/Product_Thing/ProductsData";

const StockTable = () => {
    const [orderHistory, setOrderHistory] = useState([]);
    const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
    const [searchTerm, setSearchTerm] = useState(''); // State to track search input

    // Get sales data for all years
    const salesDataByYear = useMemo(() => getSalesByYearAndMonth(orderHistoryData), [orderHistoryData]);

    // Get the sales data for the selected year, ensure type consistency in comparison
    const selectedYearData = salesDataByYear.find(data => data.year.toString() === selectedYear.toString());

    useEffect(() => {
      setOrderHistory(orderHistoryData); // Make sure this is the correct structure
    }, []);

    // Filter out products with at least one out-of-stock color
    const outOfStockProducts = initialProducts.filter(product =>
      product.colors.some(color => color.stock === 0)
    );

    // Filter products based on the search term (case-insensitive)
    const filteredProducts = outOfStockProducts.filter(product =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) // Check if the product name matches the search term
    );

    return (
      <>
      
        {/* Out of Stock Products Table */}
        <motion.div
          className="bg-gray-800 bg-opacity-50 backdrop-blur-md shadow-lg rounded-xl p-6 border border-gray-700 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
              {/* Search Bar */}

              <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-100">Out of Stock Products</h2>
          </div>
      
              <motion.div
          className="mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by product name"
            className="px-4 py-2 w-full bg-gray-700 text-gray-200 rounded-lg shadow-sm focus:outline-none"
          />
        </motion.div>

        

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
              <thead>
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Category
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Subcategory
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Color
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Stock
                  </th>
                </tr>
              </thead>

              <tbody className="divide-y divide-gray-700">
                {filteredProducts.map((product) => (
                  <motion.tr
                    key={product.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.3 }}
                  >
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-100">
                      {product.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                      {product.category}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                      {product.subCategory}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                      {product.colors
                        .filter(color => color.stock === 0) // Filter only out-of-stock colors
                        .map((color, index) => (
                          <div key={index}>
                            {color.name}
                          </div>
                        ))}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                      {product.colors
                        .filter(color => color.stock === 0) // Filter only out-of-stock colors
                        .map((color, index) => (
                          <div key={index}>
                            {color.stock}
                          </div>
                        ))}
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </>
    );
};

export default StockTable;
