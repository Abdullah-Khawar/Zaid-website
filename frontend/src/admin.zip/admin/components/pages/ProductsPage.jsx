import { motion } from "framer-motion";
import { useMemo, useState, useEffect } from "react";
import Header from "../components/common/Header";
import StatCard from "../components/common/StatCard";
import { AlertTriangle, Package } from "lucide-react";
import CategoryDistributionChart from "../components/overview/CategoryDistributionChart";
import SalesTrendChart from "../components/products/SalesTrendChart";
import ProductsTable from "../components/products/ProductsTable";
import StockTable from "../components/products/StockTable";
import { orderHistoryData } from "../components/customer/CustomerOrdersData";
import { initialProducts } from "../../../customer/components/Product_Thing/ProductsData";
import getSalesByYearAndMonth from "../components/sales/GetSalesByYearAndMonth";


const ProductsPage = () => {
  const [orderHistory, setOrderHistory] = useState([]);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  // Get sales data for all years
  const salesDataByYear = useMemo(() => getSalesByYearAndMonth(orderHistoryData), [orderHistoryData]);

  // Get the sales data for the selected year, ensure type consistency in comparison
  const selectedYearData = salesDataByYear.find(data => data.year.toString() === selectedYear.toString());

  useEffect(() => {
    setOrderHistory(orderHistoryData); // Make sure this is the correct structure
  }, []);

  // Calculate total products
  const totalProducts = initialProducts.length;

  // Calculate low stock products
  const lowStock = initialProducts.flatMap(product =>
    product.colors.filter(color => color.stock === 0)
  ).length;

  // Filter out-of-stock products
  const outOfStockProducts = initialProducts.filter(product =>
    product.colors.every(color => color.stock === 0)
  );

  

  // Get available years from sales data
  const availableYears = salesDataByYear.map(data => data.year);

  // Debugging: Log the data
  console.log("Selected Year:", selectedYear);
  console.log("Sales Data By Year:", salesDataByYear);
  console.log("Selected Year Data:", selectedYearData);

  return (
    <div className="flex-1 overflow-auto relative z-10">
      <Header title="Products" />

      <main className="max-w-7xl mx-auto py-6 px-4 lg:px-8">
        {/* STATS */}
        <motion.div
          className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <StatCard
            name="Total Products"
            icon={Package}
            value={totalProducts}
            color="#6366F1"
          />
          <StatCard
            name="Low Stock"
            icon={AlertTriangle}
            value={lowStock}
            color="#F59E0B"
          />
         
        </motion.div>

        {/* Product and stock Table */}
        <ProductsTable />
		<StockTable/>

      
      </main>
    </div>
  );
};

export default ProductsPage;
