import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  ImageIcon,
  PlusCircle,
  Tag,
  List,
  DollarSign,
  CheckCircle,
  LayoutGrid,
} from "lucide-react";
import Header from "../components/common/Header";
import { Select, MenuItem } from "@mui/material";

const colorOptions = [
  "Red",
  "Blue",
  "Green",
  "Black",
  "White",
  "Gray",
  "Yellow",
  "Pink",
  "Purple",
  "Orange",
  "Brown",
  "Beige",
  "Teal",
  "Navy",
  "Maroon",
  "LightBlue",
  "LightGreen",
  "Olive",
  "Turquoise",
  "Coral",
];

const AddProduct = ({ addProduct }) => {
  const [product, setProduct] = useState({
    name: "",
    price: "",
    discountedPrice: "",
    category: "",
    subCategory: "",
    description: "",
    stock: "",
    sizes: [],
    colors: [],
    productInfo: [
      { category: "Features", items: [] },
      { category: "Care", items: [] },
      { category: "Return Policy", items: [] },
    ],
  });

  const [color, setColor] = useState({ name: "", stock: "", imageFiles: [] });

  const handleChange = (e) => {
    setProduct({ ...product, [e.target.name]: e.target.value });
  };

  const handleColorChange = (e) => {
    setColor({ ...color, [e.target.name]: e.target.value });
  };

  const handleSizeChange = (e) => {
    const value = e.target.value;
    setProduct((prevProduct) => {
      const sizes = prevProduct.sizes.includes(value)
        ? prevProduct.sizes.filter((size) => size !== value)
        : [...prevProduct.sizes, value];
      return { ...prevProduct, sizes };
    });
  };

  const addColor = () => {
    setProduct({ ...product, colors: [...product.colors, color] });
    setColor({ name: "", stock: "", imageFiles: [] }); // Clear color fields after adding
  };

  const handleProductInfoChange = (categoryIndex, itemIndex, value) => {
    const updatedProductInfo = [...product.productInfo];
    updatedProductInfo[categoryIndex].items[itemIndex] = value;
    setProduct({ ...product, productInfo: updatedProductInfo });
  };

  const removeColor = (colorToRemove) => {
    setProduct({
      ...product,
      colors: product.colors.filter((c) => c !== colorToRemove),
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
  
    // Log the product data to the console first
    console.log({
      id: Date.now(),
      name: product.name,
      price: parseFloat(product.price),
      discountedPrice: parseFloat(product.discountedPrice),
      category: product.category,
      subCategory: product.subCategory,
      description: product.description,
      sizes: product.sizes, // Sizes array if present
      colors: product.colors.map((color) => ({
        name: color.name,
        stock: color.stock,
        images: color.imageFiles, // Including all images related to each color
      })),
      productInfo: product.productInfo, // This can include features, care, return info, etc.
    });
  
    // After confirming data is correct, you can call addProduct
    addProduct({
      id: Date.now(),
      name: product.name,
      price: parseFloat(product.price),
      discountedPrice: parseFloat(product.discountedPrice),
      category: product.category,
      subCategory: product.subCategory,
      description: product.description,
      sizes: product.sizes,
      colors: product.colors.map((color) => ({
        name: color.name,
        stock: color.stock,
        images: color.imageFiles,
      })),
      productInfo: product.productInfo,
    });
  
    // Reset the form or perform other actions after logging
    // setProduct({
    //   name: "",
    //   price: "",
    //   discountedPrice: "",
    //   category: "",
    //   subCategory: "",
    //   description: "",
    //   stock: "",
    //   sizes: [],
    //   colors: [],
    //   productInfo: [
    //     { category: "Features", items: [] },
    //     { category: "Care", items: [] },
    //     { category: "Return Policy", items: [] },
    //   ],
    // });
  };
  

  const handleColorImageChange = (e) => {
    const files = Array.from(e.target.files);
    setColor({
      ...color,
      imageFiles: [...color.imageFiles, ...files], // Append new files
    });
  };

  return (
    <div className="flex-1 items-center justify-center overflow-auto relative z-10">
      <Header title="Add Product" />

      {/* FORM SECTION */}
      <motion.div
        className="grid grid-cols-1 lg:grid-cols-1 gap-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <form onSubmit={handleSubmit}>
          {/* PRODUCT DETAILS SECTION */}
          <div className="bg-primary-900 text-white-200 p-6 w-full rounded-lg shadow-md flex-1 items-center justify-center overflow-auto relative z-10">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-100">
              <Tag className="w-5 h-5 text-white" /> Product Details
            </h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-100">
                  Product Name
                </label>
                <input
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-gray-100"
                  type="text"
                  placeholder="Product Name"
                  name="name"
                  value={product.name}
                  onChange={handleChange}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-100">
                  Product Description
                </label>
                <textarea
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-gray-100"
                  placeholder="Product Description"
                  name="description"
                  value={product.description}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-100">
                    Category
                  </label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-gray-100"
                    name="category"
                    value={product.category}
                    onChange={handleChange}
                  >
                    <option value="Clothes">Clothes</option>
                    <option value="Accessories">Accessories</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-100">
                    Subcategory
                  </label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-gray-100"
                    name="subCategory"
                    value={product.subCategory}
                    onChange={handleChange}
                  >
                    <option value="Men-Stitched">Men-Stitched</option>
                    <option value="Men-Unstitched">Men-Unstitched</option>
                    <option value="Women-Stitched">Women-Stitched</option>
                    <option value="Women-Unstitched">Women-Unstitched</option>
                    <option value="Women-Purses">Women-Purses</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-100">
                  Price
                </label>
                <input
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-gray-100"
                  type="number"
                  placeholder="Product Price"
                  name="price"
                  value={product.price}
                  onChange={handleChange}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-100">
                  Discounted Price
                </label>
                <input
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-gray-100"
                  type="number"
                  placeholder="Discounted Price"
                  name="discountedPrice"
                  value={product.discountedPrice}
                  onChange={handleChange}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-100">
                  Sizes
                </label>
                <div className="flex gap-2">
                  {["XS", "S", "M", "L", "XL"].map((size) => (
                  <button
                  key={size}
                  className={`px-3 py-1 rounded-lg ${
                    product.sizes.includes(size)
                      ? "bg-indigo-500 text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                  onClick={() =>
                    handleSizeChange({ target: { value: size } })
                  }
                >
                  {size}
                </button>
                
                  ))}
                </div>
              </div>
              <div className="border p-4">
                <h3 className="font-bold text-gray-100">Add Colors</h3>
                <Select
                  fullWidth
                  name="name"
                  value={color.name}
                  onChange={handleColorChange}
                  className="border-gray-300"
                >
                  {colorOptions.map((colorOption) => (
                    <MenuItem key={colorOption} value={colorOption}>
                      {colorOption}
                    </MenuItem>
                  ))}
                </Select>

                <input
                  type="number"
                  name="stock"
                  placeholder="Color Stock"
                  value={color.stock}
                  onChange={handleColorChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 mt-2 text-gray-100"
                />

                {/* Styled Image Upload */}
                <label
                  htmlFor="colorImage"
                  className="flex items-center justify-center h-100 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-indigo-500 transition-colors mt-2"
                >
                  {color.imageFiles.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {color.imageFiles.map((file, index) => (
                        <img
                          key={index}
                          className="w-24 h-24 object-cover rounded-lg"
                          src={URL.createObjectURL(file)}
                          alt={`Uploaded Preview ${index + 1}`}
                        />
                      ))}
                    </div>
                  ) : (
                    <span className="text-gray-500">Choose Images</span>
                  )}
                </label>
                <input
                  id="colorImage"
                  type="file"
                  multiple
                  onChange={handleColorImageChange}
                  hidden
                />

                <button
                  type="button"
                  onClick={addColor}
                  className="w-full px-6 py-3 bg-green-600 rounded-lg hover:bg-green-700 transition-colors mt-2 text-gray-100"
                >
                  Add Color
                </button>
              </div>
              {product.productInfo.map((info, categoryIndex) => (
                <div key={categoryIndex}>
                  <h3 className="text-lg font-semibold text-gray-100">
                    {info.category}
                  </h3>
                  {info.items.map((item, itemIndex) => (
                    <input
                      key={itemIndex}
                      type="text"
                      placeholder={`${info.category} Item ${itemIndex + 1}`}
                      value={item}
                      onChange={(e) =>
                        handleProductInfoChange(
                          categoryIndex,
                          itemIndex,
                          e.target.value
                        )
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 mb-2 text-gray-100"
                    />
                  ))}
                  <button
                    type="button"
                    onClick={() => {
                      const updatedProductInfo = [...product.productInfo];
                      updatedProductInfo[categoryIndex].items.push("");
                      setProduct({
                        ...product,
                        productInfo: updatedProductInfo,
                      });
                    }}
                    className="w-full px-6 py-3 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                  >
                    + Add {info.category} Item
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* SUBMIT BUTTON */}
          <motion.div
            className="mt-6 mb-6 flex justify-center" // Add flex and justify-center for centering
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <button
              type="submit"
              className="cursor-pointer w-full sm:w-auto px-6 py-3 bg-yellow-600 text-black rounded-lg hover:bg-black-700 hover:text-yellow transition-colors"
            >
              Add Product
            </button>
          </motion.div>
        </form>
      </motion.div>
    </div>
  );
};

export default AddProduct;

// import { useState } from "react";

// const AddProduct = ({ addProduct }) => {
//   const [product, setProduct] = useState({
//     name: "",
//     price: "",
//     discountedPrice: "",
//     category: "",
//     subCategory: "",
//     description: "",
//     imageSrc: [],
//     stock: "",
//     sizes: [],
//     colors: [],
//     productInfo: [
//       { category: "Features", items: [] },
//       { category: "Care", items: [] },
//       { category: "Return Policy", items: [] },
//     ],
//   });

//   const [color, setColor] = useState({ name: "", stock: "", imageSrcs: [] });

//   const handleChange = (e) => {
//     setProduct({ ...product, [e.target.name]: e.target.value });
//   };

//   const handleColorChange = (e) => {
//     setColor({ ...color, [e.target.name]: e.target.value });
//   };

//   const handleSizeChange = (e) => {
//     const value = e.target.value;
//     setProduct((prevProduct) => {
//       const sizes = prevProduct.sizes.includes(value)
//         ? prevProduct.sizes.filter((size) => size !== value)
//         : [...prevProduct.sizes, value];
//       return { ...prevProduct, sizes };
//     });
//   };

//   const addColor = () => {
//     setProduct({ ...product, colors: [...product.colors, color] });
//     setColor({ name: "", stock: "", imageSrcs: [] });
//   };

//   const handleProductInfoChange = (categoryIndex, itemIndex, value) => {
//     const updatedProductInfo = [...product.productInfo];
//     updatedProductInfo[categoryIndex].items[itemIndex] = value;
//     setProduct({ ...product, productInfo: updatedProductInfo });
//   };

//   const removeColor = (colorToRemove) => {
//     setProduct({ ...product, colors: product.colors.filter((c) => c !== colorToRemove) });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     const formData = new FormData();
//     product.imageSrc.forEach((file) => {
//       formData.append("images", file);
//     });
//     console.log(product); // Log the product data to see the structure
//     addProduct({
//       ...product,
//       id: Date.now(),
//       price: parseFloat(product.price),
//       discountedPrice: parseFloat(product.discountedPrice),
//       stock: parseInt(product.stock),
//     });
//     setProduct({
//       name: "",
//       price: "",
//       discountedPrice: "",
//       category: "",
//       subCategory: "",
//       description: "",
//       imageSrc: [],
//       stock: "",
//       sizes: [],
//       colors: [],
//       productInfo: [
//         { category: "Features", items: [] },
//         { category: "Care", items: [] },
//         { category: "Return Policy", items: [] },
//       ],
//     });
//   };
//   const handleColorImageChange = (e) => {
//     const files = Array.from(e.target.files);
//     setColor({ ...color, imageFiles: files });
//   };

//   return (
//     <div className="p-6 w-full">
//       <h2 className="text-2xl font-bold mb-4">Add Product</h2>
//       <form onSubmit={handleSubmit} className="space-y-4">
//         <input
//           type="text"
//           name="name"
//           placeholder="Product Name"
//           value={product.name}
//           onChange={handleChange}
//           className="w-full p-2 border"
//           required
//         />
//         <input
//           type="number"
//           name="price"
//           placeholder="Price"
//           value={product.price}
//           onChange={handleChange}
//           className="w-full p-2 border"
//           required
//         />
//         <input
//           type="number"
//           name="discountedPrice"
//           placeholder="Discounted Price"
//           value={product.discountedPrice}
//           onChange={handleChange}
//           className="w-full p-2 border"
//         />

//         <select
//           name="category"
//           value={product.category}
//           onChange={handleChange}
//           className="w-full p-2 border"
//         >
//           <option value="Clothes">Clothes</option>
//           <option value="Accessories">Accessories</option>
//         </select>
//         <select
//           name="subCategory"
//           value={product.subCategory}
//           onChange={handleChange}
//           className="w-full p-2 border"
//         >
//           <option value="Men-Stitched">Men-Stitched</option>
//           <option value="Men-Unstitched">Men-Unstitched</option>
//           <option value="Women-Stitched">Women-Stitched</option>
//           <option value="Women-Unstitched">Women-Unstitched</option>
//           <option value="Women-Purses">Women-Purses</option>
//         </select>

//         <textarea
//           name="description"
//           placeholder="Description"
//           value={product.description}
//           onChange={handleChange}
//           className="w-full p-2 border"
//           required
//         ></textarea>

//          {/* Color Input with Image Upload */}
//          <div className="border p-4">
//           <h3 className="font-bold">Add Colors</h3>
//           <input type="text" name="name" placeholder="Color Name" value={color.name} onChange={handleColorChange} className="w-full p-2 border" />
//           <input type="number" name="stock" placeholder="Color Stock" value={color.stock} onChange={handleColorChange} className="w-full p-2 border" />
//           <input type="file" multiple onChange={handleColorImageChange} className="w-full p-2 border" />
//           <button type="button" onClick={addColor} className="bg-green-600 text-white p-2 mt-2">Add Color</button>
//         </div>

//         {/* Size Selection */}
//         <div className="border p-4">
//           <h3 className="font-bold">Select Sizes</h3>
//           {["XS", "S", "M", "L", "XL"].map((size) => (
//             <label key={size} className="inline-flex items-center mr-4">
//               <input
//                 type="checkbox"
//                 value={size}
//                 onChange={handleSizeChange}
//                 checked={product.sizes.includes(size)}
//                 className="mr-2"
//               />
//               {size}
//             </label>
//           ))}
//         </div>

//         {/* Features, Care, Return Policy */}
//         {product.productInfo.map((info, categoryIndex) => (
//           <div key={categoryIndex}>
//             <h3 className="text-lg font-semibold">{info.category}</h3>
//             {info.items.map((item, itemIndex) => (
//               <input
//                 key={itemIndex}
//                 type="text"
//                 placeholder={`${info.category} Item ${itemIndex + 1}`}
//                 value={item}
//                 onChange={(e) => handleProductInfoChange(categoryIndex, itemIndex, e.target.value)}
//                 className="w-full p-2 border mb-2"
//               />
//             ))}
//             <button
//               type="button"
//               onClick={() => {
//                 const updatedProductInfo = [...product.productInfo];
//                 updatedProductInfo[categoryIndex].items.push("");
//                 setProduct({ ...product, productInfo: updatedProductInfo });
//               }}
//               className="bg-gray-500 text-white p-2 mt-2"
//             >
//               + Add {info.category} Item
//             </button>
//           </div>
//         ))}

//         <button type="submit" className="bg-blue-600 text-white p-2 w-full">
//           Add Product
//         </button>
//       </form>
//     </div>
//   );
// };

// export default AddProduct;

// If you want beautiful Image Upload signs Add this Code at 334

{
  /* IMAGE UPLOAD SECTION */
}
{
  /* <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-100">
              <ImageIcon className="w-5 h-5 text-gray-100" /> Upload Images
            </h2>
            <div className="grid grid-cols-2 gap-4">
              {[1, 2, 3, 4].map((index) => (
                <label
                  key={index}
                  htmlFor={`image${index}`}
                  className="flex items-center justify-center h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-indigo-500 transition-colors"
                >
                  <img
                    className="w-full h-full object-cover rounded-lg"
                    src={!product.imageSrc[index - 1] ? "/upload_area.png" : URL.createObjectURL(product.imageSrc[index - 1])}
                    alt=""
                  />
                  <input
                    onChange={(e) => {
                      const files = Array.from(e.target.files);
                      setProduct((prev) => ({
                        ...prev,
                        imageSrc: [...prev.imageSrc, ...files],
                      }));
                    }}
                    type="file"
                    id={`image${index}`}
                    hidden
                  />
                </label>
              ))}
            </div>
          </div> */
}
