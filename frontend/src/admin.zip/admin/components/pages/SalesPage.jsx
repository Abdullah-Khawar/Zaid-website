import { motion } from "framer-motion";
import Header from "../components/common/Header";
import StatCard from "../components/common/StatCard";
import { CreditCard, DollarSign, ShoppingCart, TrendingUp } from "lucide-react";
import SalesOverviewChart from "../components/sales/SalesOverviewChart";
import SalesByCategoryChart from "../components/sales/SalesByCategoryChart";
import DailySalesTrend from "../components/sales/DailySalesTrend";
import { useMemo, useEffect, useState } from "react";
import { orderHistoryData } from "../components/customer/CustomerOrdersData";
import getSalesByYearAndMonth from "../components/sales/GetSalesByYearAndMonth";
import SalesTrendChart from "../components/products/SalesTrendChart";

const SalesPage = () => {
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  // Get sales data for all years
  const salesDataByYear = useMemo(
    () => getSalesByYearAndMonth(orderHistoryData),
    [orderHistoryData]
  );

  // Get the sales data for the selected year, ensure type consistency in comparison
  const selectedYearData = salesDataByYear.find(
    (data) => data.year.toString() === selectedYear.toString()
  );

  // Get available years from sales data
  const availableYears = salesDataByYear.map((data) => data.year);

  // Debugging: Log the data
  console.log("Selected Year:", selectedYear);
  console.log("Sales Data By Year:", salesDataByYear);
  console.log("Selected Year Data:", selectedYearData);
  // Hooks should be inside the functional component
  const [orderHistory, setOrderHistory] = useState([]);

  useEffect(() => {
    setOrderHistory(orderHistoryData); // Ensure the data structure is correct
  }, []);

  // Calculate total revenue using useMemo to optimize
  const totalRevenue = useMemo(() => {
    return orderHistory.reduce((acc, customer) => {
      return (
        acc +
        customer.orders
          .filter((order) => order.orderStatus === "delivered")
          .reduce((orderTotal, order) => orderTotal + order.totalAmount, 0)
      );
    }, 0);
  }, [orderHistory]);

  return (
    <div className="flex-1 overflow-auto relative z-10">
      <Header title="Sales Dashboard" />

      <main className="max-w-7xl mx-auto py-6 px-4 lg:px-8">
        {/* SALES STATS */}
        <motion.div
          className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <StatCard
            name="Total Revenue"
            icon={DollarSign}
            value={totalRevenue}
            color="#6366F1"
          />

         
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-1 gap-8 mb-8">
          {/* Dropdown to select the year */}

		  <div className="grid grid-cols-1 lg:grid-cols-1 gap-8 mb-8">
          <div className="flex flex-col space-y-4">
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(Number(e.target.value))}
              className="w-full p-2 bg-white text-gray-800 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {availableYears.map((year) => (
                <option key={year} value={year}>
                  {year}
                </option>
              ))}
            </select>
          </div>

          {/* Check if selectedYearData exists before rendering chart */}
          {selectedYearData ? (
            <SalesTrendChart salesData={selectedYearData.months} />
          ) : (
            <p className="text-center text-gray-500">
              No data available for this year
            </p>
          )}
</div>
          <SalesByCategoryChart />
          <DailySalesTrend orderHistoryData={orderHistoryData} />
        </div>
      </main>
    </div>
  );
};

export default SalesPage;
