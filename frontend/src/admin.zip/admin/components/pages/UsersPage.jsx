import { UserCheck, UserPlus, UsersIcon, UserX } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "react-toastify";  // Importing react-toastify

import Header from "../components/common/Header";
import StatCard from "../components/common/StatCard";
import UsersTable from "../components/users/UsersTable"; // Assuming UsersTable component handles displaying the users data
import UserGrowthChart from "../components/users/UserGrowthChart";

import users from "../components/customer/UsersData"; // Import users data
import { useState } from "react";
const UsersPage = () => {
  // State to hold users data (this could come from a backend or context)
  const [userList, setUserList] = useState(users); // State for user list

  // Calculate user statistics based on the users array
  const totalUsers = userList.length;

  const newUsersToday = userList.filter(user => {
    const today = new Date();
    const userCreatedAt = new Date(user.createdAt); // Assuming users have a `createdAt` property
    return (
      userCreatedAt.getDate() === today.getDate() &&
      userCreatedAt.getMonth() === today.getMonth() &&
      userCreatedAt.getFullYear() === today.getFullYear()
    );
  }).length;

  const activeUsers = userList.filter(user => {
    const lastLogin = new Date(user.lastLogin); // Assuming users have a `lastLogin` property
    const oneMonthAgo = new Date();
    oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
    return lastLogin >= oneMonthAgo; // Active if logged in within the last month
  }).length;

  const churnedUsers = userList.filter(user => {
    const lastLogin = new Date(user.lastLogin);
    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
    return lastLogin <= threeMonthsAgo; // Churned if last login was more than 3 months ago
  }).length;

  const churnRate = (churnedUsers / totalUsers * 100).toFixed(1); // Percentage of churned users

  const handleDeleteUser = (userId) => {
    // Initial Toast for Deletion Confirmation
    const toastId = toast.loading("Are you sure you want to delete this user?", {
      position: "top-center",
      autoClose: false,
    });

    // Show confirmation toast
    toast.info(
      <div>
        <span>Are you sure?</span>
        <div>
          <button
            onClick={() => handleConfirmDelete(userId, toastId)}
            className="bg-red-500 text-white py-1 px-3 rounded"
          >
            Yes
          </button>
          <button
            onClick={() => toast.dismiss(toastId)}
            className="bg-gray-500 text-white py-1 px-3 rounded ml-2"
          >
            No
          </button>
        </div>
      </div>,
      { autoClose: false }
    );
  };

  const handleConfirmDelete = (userId, toastId) => {
    // Remove user from the list
    const updatedUsers = userList.filter(user => user.id !== userId);
    setUserList(updatedUsers);

    // Hide the initial toast and show confirmation of deletion
    toast.update(toastId, {
      render: "User deleted successfully!",
      type: "success",
      isLoading: false,
      autoClose: 2000,
    });
  };

  return (
    <div className='flex-1 overflow-auto relative z-10'>
      <Header title='Users' />

      <main className='max-w-7xl mx-auto py-6 px-4 lg:px-8'>
        {/* STATS */}
        <motion.div
          className='grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8'
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <StatCard
            name='Total Users'
            icon={UsersIcon}
            value={totalUsers.toLocaleString()}
            color='#6366F1'
          />
        
         
        </motion.div>

        {/* Displaying the Users Table */}
        <UsersTable users={userList} onDelete={handleDeleteUser} />

        {/* USER CHARTS */}
        <div className='grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8'>
          <UserGrowthChart />
        </div>
      </main>
    </div>
  );
};

export default UsersPage;
