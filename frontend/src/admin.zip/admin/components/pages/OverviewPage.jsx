import { BarChart2, ShoppingBag, Users, Zap } from "lucide-react";
import { motion } from "framer-motion";

import Header from "../components/common/Header";
import StatCard from "../components/common/StatCard";
import SalesOverviewChart from "../components/overview/SalesOverviewChart";
import CategoryDistributionChart from "../components/overview/CategoryDistributionChart";
import SalesChannelChart from "../components/overview/SalesChannelChart";
import { initialProducts } from "../components/customer/ProductsData";
import SalesByCategoryChart from "../components/sales/SalesByCategoryChart";
import { orderHistoryData } from "../components/customer/CustomerOrdersData";
import { useState, useEffect, useMemo } from "react";
import users from "../components/customer/UsersData";

const OverviewPage = () => {

  const [orderHistory, setOrderHistory] = useState([]);

  useEffect(() => {
    setOrderHistory(orderHistoryData); // Make sure this is the correct structure
  }, []);

  // Calculate total products
  const totalProducts = initialProducts.length;

  // Calculate total delivered products (sum of quantity from all delivered orders)
  const totalDeliveredProducts = useMemo(() => {
    return orderHistory.reduce((acc, customer) => {
      return acc + customer.orders
        .filter(order => order.orderStatus === "delivered") // Only consider delivered orders
        .reduce((orderAcc, order) => orderAcc + order.products.reduce((productAcc, product) => productAcc + product.quantity, 0), 0); // Sum the quantities of all products
    }, 0);
  }, [orderHistory]);

  // Calculate total users (length of the users array)
  const totalUsers = users.length;

  return (
    <div className='flex-1 overflow-auto relative z-10'>
      <Header title='Overview' />

      <main className='max-w-7xl mx-auto py-6 px-4 lg:px-8'>
        {/* STATS */}
        <motion.div
          className='grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8'
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <StatCard name='Total Sales (Delivered Products)' icon={Zap} value={totalDeliveredProducts} color='#6366F1' />
          <StatCard name='Total Customers' icon={Users} value={totalUsers} color='#8B5CF6' />
          <StatCard name='Total Products' icon={ShoppingBag} value={totalProducts} color='#EC4899' />
        </motion.div>

        {/* CHARTS */}
        <div className='grid grid-cols-1 lg:grid-cols-1 gap-8'>
          <SalesByCategoryChart/>
          <CategoryDistributionChart initialProducts={initialProducts} />
          {/* <SalesChannelChart /> */}
        </div>
      </main>
    </div>
  );
};
export default OverviewPage;
