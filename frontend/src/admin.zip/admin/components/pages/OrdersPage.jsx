import { CheckCircle, Clock, DollarSign, ShoppingBag } from "lucide-react";
import { motion } from "framer-motion";

import Header from "../components/common/Header";
import StatCard from "../components/common/StatCard";
import DailyOrders from "../components/orders/DailyOrders";
import OrderDistribution from "../components/orders/OrderDistribution";
import OrdersTable from "../components/orders/OrdersTable";

import { orderHistoryData } from "../components/customer/CustomerOrdersData";

const OrdersPage = () => {
  // Dynamically calculate order statistics
  const calculateOrderStats = () => {
    let totalOrders = 0;
    let pendingOrders = 0;
    let completedOrders = 0; // Excludes pending and cancelled
    let cancelledOrders = 0;
    let shippedOrders = 0;

    orderHistoryData.forEach((customer) => {
      customer.orders.forEach((order) => {
        totalOrders += 1;
        switch (order.orderStatus) {
          case "pending":
            pendingOrders += 1;
            break;
          case "cancelled":
            cancelledOrders += 1;
            break;
          case "shipped":
            shippedOrders += 1;
            break;
          case "delivered":
            completedOrders += 1;
            break;
          default:
            break;
        }
      });
    });

    return {
      totalOrders,
      pendingOrders,
      completedOrders,
      cancelledOrders,
      shippedOrders,
    };
  };

  const orderStats = calculateOrderStats();

  return (
    <div className="flex-1 relative z-10 overflow-auto">
      <Header title={"Orders"} />

      <main className="max-w-7xl mx-auto py-6 px-4 lg:px-8">
        <motion.div
          className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <StatCard
            name="Total Orders"
            icon={ShoppingBag}
            value={orderStats.totalOrders}
            color="#6366F1"
          />
          <StatCard
            name="Pending Orders"
            icon={Clock}
            value={orderStats.pendingOrders}
            color="#F59E0B"
          />
          <StatCard
            name="Completed Orders"
            icon={CheckCircle}
            value={orderStats.completedOrders}
            color="#10B981"
          />
          <StatCard
            name="Cancelled Orders"
            icon={DollarSign}
            value={orderStats.cancelledOrders}
            color="#EF4444"
          />
          <StatCard
            name="Shipped Orders"
            icon={DollarSign}
            value={orderStats.shippedOrders}
            color="#4ECDC4"
          />
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <DailyOrders />
          <OrderDistribution />
        </div>

        <OrdersTable />
      </main>
    </div>
  );
};
export default OrdersPage;
